#pragma once
/**
 * RecursiveFunctions.h
 *
 * Header file for Task 2 - Recursive Functions
 * Contains declarations for 6 recursive functions
 */


 // Function 1: Prints numbers from n down to 1 recursively
 // Example: funcRecursive(5) prints: 5 4 3 2 1
void funcRecursive(int n);

// Function 2: Calculates sum from n down to 1 recursively
// Example: sumRecursive(5) returns 15 (5+4+3+2+1)
int sumRecursive(int n);

// Function 3: Finds maximum element in array recursively
// Example: maxRecursive([3,7,2,9,1], 5) returns 9
int maxRecursive(int arr[], int size);

// Function 4: Counts non-zero digits in a number recursively
// Example: countDigitsRecursive(1002003) returns 4
int countDigitsRecursive(int n);

// Function 5: Displays digits of a number in reverse order recursively
// Example: displayDigitsRecursive(12345) prints: 5 4 3 2 1
void displayDigitsRecursive(int n);

// Function 6: Searches for a value in sorted array using binary search recursively
// Example: binarySearchRecursive([1,3,5,7,9], 0, 4, 5) returns 2
//          binarySearchRecursive([1,3,5,7,9], 0, 4, 6) returns -1
int binarySearchRecursive(int arr[], int low, int high, int value);

