﻿/**
 * RecursiveFunctions.cpp
 *
 * Implementation file for Task 2 - Recursive Functions
 *
 * Step 1 - Understanding the Task:
 * Convert 6 iterative functions into recursive versions:
 * - func: prints numbers from n down to 1
 * - sum: calculates sum from n down to 1
 * - max: finds maximum element in array
 * - countDigits: counts non-zero digits in a number
 * - displayDigits: displays digits in reverse order
 * - binarySearch: searches sorted array using divide-and-conquer
 *
 * Step 2 - Solution Approach (Base Case + Recursive Case):
 *
 * For func(n):
 *   Base case: if n <= 0, stop
 *   Recursive case: print n, then call func(n-1)
 *   Example: func(3) prints 3 -> func(2) prints 2 -> func(1) prints 1
 *
 * For sum(n):
 *   Base case: if n <= 0, return 0
 *   Recursive case: return n + sum(n-1)
 *   Example: sum(3) = 3 + sum(2) = 3 + 2 + sum(1) = 3 + 2 + 1 = 6
 *
 * For max(arr, size):
 *   Base case: if size == 1, return arr[0]
 *   Recursive case: return max(arr[size-1], max(arr, size-1))
 *
 * For countDigits(n):
 *   Base case: if n <= 0, return 0
 *   Recursive case: return (n%10 != 0 ? 1 : 0) + countDigits(n/10)
 *
 * For displayDigits(n):
 *   Base case: if n <= 0, return
 *   Recursive case: print n%10, then call displayDigits(n/10)
 *
 * For binarySearch(arr, low, high, v):
 *   Base case: if low > high, return -1
 *   Base case: if arr[mid] == v, return mid
 *   Recursive case: if v > arr[mid], search right half
 *                 if v < arr[mid], search left half
 *
 * Step 3 - Functions Used and Why:
 * Each recursive function calls itself with smaller input until reaching base case.
 *
 * Step 4 - Learning:
 * Recursion breaks complex problems into simpler subproblems.
 *
 * Step 5 - Skills Developed:
 * Can convert iterative functions to recursion.
 */

#include "RecursiveFunctions.h"
#include <iostream>
using namespace std;

// 1. Recursive function to print numbers from n down to 1
void funcRecursive(int n) {
    // Base case: smallest input - nothing to print
    if (n <= 0) {
        return;
    }
    // Print current number then recurse with n-1
    cout << n << endl;
    funcRecursive(n - 1);  // -> RECURSION HERE!
}

// 2. Recursive function to calculate sum from n down to 1
int sumRecursive(int n) {
    // Base case: if n <= 0, sum is 0
    if (n <= 0) {
        return 0;
    }
    // Recursive case: n + sum of numbers from (n-1) down to 1
    return n + sumRecursive(n - 1);  // -> RECURSION HERE!
}

// 3. Recursive function to find maximum element in array
int maxRecursive(int arr[], int size) {
    // Base case: only one element, it's the maximum
    if (size == 1) {
        return arr[0];
    }
    // Recursive case: max of last element and max of rest of array
    int maxOfRest = maxRecursive(arr, size - 1);  // -> RECURSION HERE!
    return (arr[size - 1] > maxOfRest) ? arr[size - 1] : maxOfRest;
}

// 4. Recursive function to count non-zero digits
int countDigitsRecursive(int n) {
    // Base case: no digits left
    if (n <= 0) {
        return 0;
    }
    // Check last digit: add 1 if non-zero, then recurse with n/10
    return ((n % 10 != 0) ? 1 : 0) + countDigitsRecursive(n / 10);  // -> RECURSION HERE!
}

// 5. Recursive function to display digits in reverse order
void displayDigitsRecursive(int n) {
    // Base case: no digits left
    if (n <= 0) {
        cout << endl;
        return;
    }
    // Print last digit first, then recurse with n/10
    cout << n % 10 << " ";
    displayDigitsRecursive(n / 10);  // -> RECURSION HERE!
}

// 6. Recursive binary search function
int binarySearchRecursive(int arr[], int low, int high, int value) {
    // Base case: element not found
    if (low > high) {
        return -1;
    }

    int mid = (low + high) / 2;

    // Base case: element found at mid
    if (arr[mid] == value) {
        return mid;
    }

    // Recursive cases: search left or right half
    if (value > arr[mid]) {
        // Search in right half (higher indices)
        return binarySearchRecursive(arr, mid + 1, high, value);  // -> RECURSION HERE!
    }
    else {
        // Search in left half (lower indices)
        return binarySearchRecursive(arr, low, mid - 1, value);   // -> RECURSION HERE!
    }
}