

#include <iostream>
using namespace std;

const int DEFAULT_CAPACITY = 100;

template <typename T>
class ArrayStack {
private:
    T* data;
    int topIndex;
    int capacity;

    void resize();

public:
    ArrayStack(int cap = DEFAULT_CAPACITY);
    ArrayStack(const ArrayStack& other);
    ~ArrayStack();

    bool push(T val);
    bool pop(T& val);
    bool peek(T& val) const;
    bool isEmpty() const;
    bool isFull() const;
    int getSize() const;
    void clear();

    // Assignment operator
    ArrayStack<T>& operator=(const ArrayStack<T>& other);
};




template <typename T>
ArrayStack<T>::ArrayStack(int cap) : capacity(cap), topIndex(-1) {
    data = new T[capacity];
}

template <typename T>
ArrayStack<T>::ArrayStack(const ArrayStack<T>& other) {
    capacity = other.capacity;
    topIndex = other.topIndex;
    data = new T[capacity];
    for (int i = 0; i <= topIndex; i++) {
        data[i] = other.data[i];
    }
}

template <typename T>
ArrayStack<T>::~ArrayStack() {
    delete[] data;
}

template <typename T>
void ArrayStack<T>::resize() {
    capacity *= 2;
    T* newData = new T[capacity];
    for (int i = 0; i <= topIndex; i++) {
        newData[i] = data[i];
    }
    delete[] data;
    data = newData;
}

template <typename T>
bool ArrayStack<T>::push(T val) {
    if (isFull()) {
        resize();
    }
    data[++topIndex] = val;
    return true;
}

template <typename T>
bool ArrayStack<T>::pop(T& val) {
    if (isEmpty()) {
        return false;
    }
    val = data[topIndex--];
    return true;
}

template <typename T>
bool ArrayStack<T>::peek(T& val) const {
    if (isEmpty()) {
        return false;
    }
    val = data[topIndex];
    return true;
}

template <typename T>
bool ArrayStack<T>::isEmpty() const {
    return topIndex == -1;
}

template <typename T>
bool ArrayStack<T>::isFull() const {
    return topIndex == capacity - 1;
}

template <typename T>
int ArrayStack<T>::getSize() const {
    return topIndex + 1;
}

template <typename T>
void ArrayStack<T>::clear() {
    topIndex = -1;
}

template <typename T>
ArrayStack<T>& ArrayStack<T>::operator=(const ArrayStack<T>& other) {
    if (this != &other) {
        delete[] data;
        capacity = other.capacity;
        topIndex = other.topIndex;
        data = new T[capacity];
        for (int i = 0; i <= topIndex; i++) {
            data[i] = other.data[i];
        }
    }
    return *this;
}

