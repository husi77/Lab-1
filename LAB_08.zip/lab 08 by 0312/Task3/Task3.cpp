/**
 * Task 3: Recursive Functions on ArrayStack
 *
 * Step 1 - Understanding the Task:
 * We need to convert iterative stack functions (copyStack, display, getSize, max)
 * into recursive versions, and implement a frequency function recursively.
 *
 * Frequency function: Count how many times each value appears in the stack
 * and return a new stack containing these frequencies.
 *
 * Example: Stack has [1,2,1,3,1,2] (top to bottom)
 * Frequency stack could be [1:3, 2:2, 3:1] or any format
 *
 * Step 2 - Solution Approach:
 * For each recursive function:
 * - Base case: stack becomes empty
 * - Recursive case: process top element, then recurse on remaining stack
 *
 * For frequency:
 * - Helper function to count occurrences of a value
 * - Helper function to get unique values
 * - Recursively build frequency stack
 *
 * Step 3 - Functions Used and Why:
 * - copyStackRecursive: pops top, recurses, then pushes to copy (reverses order)
 * - displayRecursive: pops top, displays it, recurses
 * - getSizeRecursive: pops top, adds 1 + size of remaining
 * - maxRecursive: tracks maximum while recursing
 * - frequency: uses helper functions to count and return frequencies
 *
 * Step 4 - Learning:
 * Recursion on stacks must carefully handle order reversal since pop removes elements.
 * Need to restore original stack or work with copies.
 *
 * Step 5 - Skills Developed:
 * Can implement recursive algorithms on stack data structures.
 */

#include <iostream>
#include <map>
#include <vector>
using namespace std;

// Assuming ArrayStack is provided
template <typename T>
class ArrayStack {
private:
    T* data;
    int topIndex;
    int capacity;
    static const int DEFAULT_CAPACITY = 100;

    void resize() {
        capacity *= 2;
        T* newData = new T[capacity];
        for (int i = 0; i <= topIndex; i++) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
    }

public:
    ArrayStack(int cap = DEFAULT_CAPACITY) : capacity(cap), topIndex(-1) {
        data = new T[capacity];
    }

    ArrayStack(const ArrayStack<T>& other) {
        capacity = other.capacity;
        topIndex = other.topIndex;
        data = new T[capacity];
        for (int i = 0; i <= topIndex; i++) {
            data[i] = other.data[i];
        }
    }

    ~ArrayStack() {
        delete[] data;
    }

    bool push(T val) {
        if (topIndex + 1 >= capacity) {
            resize();
        }
        data[++topIndex] = val;
        return true;
    }

    bool pop(T& val) {
        if (isEmpty()) {
            return false;
        }
        val = data[topIndex--];
        return true;
    }

    bool peek(T& val) const {
        if (isEmpty()) {
            return false;
        }
        val = data[topIndex];
        return true;
    }

    bool isEmpty() const {
        return topIndex == -1;
    }

    int getSize() const {
        return topIndex + 1;
    }

    void clear() {
        topIndex = -1;
    }

    // Helper to get element at index (for display purposes)
    T getElementAt(int index) const {
        return data[index];
    }

    // Make a copy of the stack
    ArrayStack<T> copy() const {
        ArrayStack<T> newStack(capacity);
        for (int i = 0; i <= topIndex; i++) {
            newStack.push(data[i]);
        }
        return newStack;
    }
};

// ========== RECURSIVE FUNCTIONS ==========

/**
 * Recursive copyStack
 * Copies all elements from src stack to copy stack
 * Note: This will reverse the order due to popping
 */
template <typename T>
void copyStackRecursive(ArrayStack<T>& src, ArrayStack<T>& copy) {
    // Base case: src is empty
    if (src.isEmpty()) {
        return;
    }

    // Recursive case: pop top element, recurse, then push to copy
    T val;
    src.pop(val);

    // Recurse on remaining stack
    copyStackRecursive(src, copy);

    // After recursion, push to copy (maintains original order)
    copy.push(val);
}

/**
 * Recursive display function
 * Displays all elements in the stack from top to bottom
 */
template <typename T>
void displayRecursive(ArrayStack<T>& stack) {
    // Base case: stack is empty
    if (stack.isEmpty()) {
        cout << endl;
        return;
    }

    // Recursive case: pop top, display it, recurse on remaining
    T val;
    stack.pop(val);

    cout << val << " ";
    displayRecursive(stack);

    // Note: Original stack gets destroyed in this process
    // For a non-destructive version, we'd need a helper
}

/**
 * Non-destructive recursive display
 * Displays without destroying the original stack
 */
template <typename T>
void displayRecursiveNonDestructive(ArrayStack<T> stack) {
    if (stack.isEmpty()) {
        cout << endl;
        return;
    }

    T val;
    stack.pop(val);
    cout << val << " ";
    displayRecursiveNonDestructive(stack);
}

/**
 * Recursive getSize function
 * Returns the number of elements in the stack
 */
template <typename T>
int getSizeRecursive(ArrayStack<T>& stack) {
    // Base case: stack is empty
    if (stack.isEmpty()) {
        return 0;
    }

    // Recursive case: pop one element, add 1 to size of remaining
    T val;
    stack.pop(val);

    int size = 1 + getSizeRecursive(stack);

    // Push back to restore original stack (optional)
    // stack.push(val);

    return size;
}

/**
 * Non-destructive recursive getSize
 */
template <typename T>
int getSizeRecursiveNonDestructive(ArrayStack<T> stack) {
    if (stack.isEmpty()) {
        return 0;
    }

    T val;
    stack.pop(val);
    return 1 + getSizeRecursiveNonDestructive(stack);
}

/**
 * Recursive max function (destructive - destroys original stack)
 * Finds maximum value in the stack
 */
template <typename T>
T maxRecursive(ArrayStack<T>& stack) {
    // Base case: only one element left
    T val;
    stack.pop(val);

    if (stack.isEmpty()) {
        return val;
    }

    // Recursive case: find max of remaining stack
    T maxOfRest = maxRecursive(stack);

    // Return the larger value
    return (val > maxOfRest) ? val : maxOfRest;
}

/**
 * Non-destructive recursive max
 */
template <typename T>
T maxRecursiveNonDestructive(ArrayStack<T> stack) {
    T val;
    stack.pop(val);

    if (stack.isEmpty()) {
        return val;
    }

    T maxOfRest = maxRecursiveNonDestructive(stack);
    return (val > maxOfRest) ? val : maxOfRest;
}

// ========== FREQUENCY FUNCTIONS ==========

/**
 * Helper: Count frequency of a specific value in stack (recursive)
 */
template <typename T>
int countFrequencyRecursive(ArrayStack<T>& stack, T target) {
    // Base case: stack is empty
    if (stack.isEmpty()) {
        return 0;
    }

    T val;
    stack.pop(val);

    // Count this element if it matches target
    int count = (val == target) ? 1 : 0;

    // Add count from remaining stack
    count += countFrequencyRecursive(stack, target);

    // Restore the stack (push back in reverse order)
    // This is tricky because order matters
    return count;
}

/**
 * Helper: Get all unique values from stack (recursive)
 * Returns a stack of unique values
 */
template <typename T>
ArrayStack<T> getUniqueValuesRecursive(ArrayStack<T>& stack, ArrayStack<T>& result) {
    if (stack.isEmpty()) {
        return result;
    }

    T val;
    stack.pop(val);

    // Check if val already in result (need to check recursively)
    // For simplicity, we'll use a different approach

    // Recurse first
    getUniqueValuesRecursive(stack, result);

    // Then add if not already present (simplified version)
    result.push(val);

    return result;
}

/**
 * Frequency function - returns a stack containing frequency of each unique value
 * Format: For each unique value, push (value and its count)
 * We'll use a helper function that builds a frequency map recursively
 */
template <typename T>
void buildFrequencyMapRecursive(ArrayStack<T>& stack, map<T, int>& freqMap) {
    // Base case: stack is empty
    if (stack.isEmpty()) {
        return;
    }

    T val;
    stack.pop(val);

    // Increment frequency in map
    freqMap[val]++;

    // Recurse on remaining stack
    buildFrequencyMapRecursive(stack, freqMap);
}

/**
 * Helper: Convert frequency map to stack recursively
 */
template <typename T>
void mapToStackRecursive(typename map<T, int>::iterator it,
    typename map<T, int>::iterator end,
    ArrayStack<T>& result) {
    // Base case: reached end of map
    if (it == end) {
        return;
    }

    // Recursive case: process current element then move to next
    // Push value and its count (we'll push count after value)
    // For simplicity, we'll push value and count as separate entries
    // Or we can create a pair structure

    T val = it->first;
    int count = it->second;

    // Recurse to next element
    mapToStackRecursive(++it, end, result);

    // Push count then value (so when popped, value comes first)
    // This is a simple representation - value then its frequency
    result.push(val);
    result.push(count);
}

/**
 * Main frequency function (recursive)
 * Calculates frequency of each value and returns in a stack
 */
template <typename T>
ArrayStack<T> frequency(ArrayStack<T> stack) {
    // Step 1: Build frequency map recursively
    map<T, int> freqMap;
    buildFrequencyMapRecursive(stack, freqMap);

    // Step 2: Convert map to stack recursively
    ArrayStack<T> result;
    mapToStackRecursive(freqMap.begin(), freqMap.end(), result);

    return result;
}

/**
 * Alternative frequency function that returns a stack of strings
 * For better readability, we can return a stack of pairs
 * But since we're working with ints, we'll use two stacks or a struct
 */

 // Structure to hold value and its frequency
struct FrequencyPair {
    int value;
    int count;

    FrequencyPair(int v = 0, int c = 0) : value(v), count(c) {}
};

// Stack of FrequencyPair (needs custom implementation or use vector)
// Simplified: Return two stacks - one for values, one for frequencies

/**
 * Alternative: Return a single stack with values and counts interleaved
 * When you pop, you get value then its frequency
 */
template <typename T>
ArrayStack<T> frequencyInterleaved(ArrayStack<T> stack) {
    map<T, int> freqMap;
    buildFrequencyMapRecursive(stack, freqMap);

    ArrayStack<T> result;

    // Use iterator recursively
    typename map<T, int>::iterator it = freqMap.end();

    // Helper lambda for recursive insertion
    function<void(typename map<T, int>::iterator)> addToStack = [&](typename map<T, int>::iterator iter) {
        if (iter == freqMap.begin()) {
            return;
        }
        --iter;
        result.push(iter->second);  // Push count first
        result.push(iter->first);   // Then push value
        addToStack(iter);
        };

    addToStack(freqMap.end());
    return result;
}

// ========== TESTING ==========

int main() {
    cout << "========== TASK 3: RECURSIVE FUNCTIONS ON ARRAYSTACK ==========\n\n";

    // Create and populate a test stack
    ArrayStack<int> originalStack;

    cout << "Pushing elements onto stack: ";
    int testData[] = { 5, 2, 8, 2, 5, 2, 9, 5, 1 };
    for (int i = 0; i < 9; i++) {
        originalStack.push(testData[i]);
        cout << testData[i] << " ";
    }
    cout << endl;

    // Test 1: copyStackRecursive
    cout << "\n--- Test 1: copyStackRecursive ---" << endl;
    ArrayStack<int> copyStack1;
    ArrayStack<int> copyStack2 = originalStack.copy(); // Make a copy to work with

    cout << "Original stack (destructive copy): ";
    displayRecursiveNonDestructive(originalStack.copy());

    copyStackRecursive(copyStack2, copyStack1);
    cout << "Copied stack: ";
    displayRecursiveNonDestructive(copyStack1);

    // Test 2: displayRecursive (destructive version demonstration)
    cout << "\n--- Test 2: displayRecursive (destructive) ---" << endl;
    ArrayStack<int> displayStack = originalStack.copy();
    cout << "Displaying stack (destructive): ";
    displayRecursive(displayStack);
    cout << "After destructive display, stack is empty: " << (displayStack.isEmpty() ? "Yes" : "No") << endl;

    // Test 3: getSizeRecursive
    cout << "\n--- Test 3: getSizeRecursive ---" << endl;
    ArrayStack<int> sizeStack = originalStack.copy();
    int size = getSizeRecursiveNonDestructive(sizeStack);
    cout << "Stack size (non-destructive): " << size << endl;
    cout << "Expected size: 9" << endl;

    // Test 4: maxRecursive
    cout << "\n--- Test 4: maxRecursive ---" << endl;
    ArrayStack<int> maxStack = originalStack.copy();
    int maxVal = maxRecursiveNonDestructive(maxStack);
    cout << "Maximum value in stack: " << maxVal << endl;
    cout << "Expected max: 9" << endl;

    // Test 5: frequency function
    cout << "\n--- Test 5: frequency ---" << endl;
    ArrayStack<int> freqStack = originalStack.copy();
    ArrayStack<int> resultStack = frequency(freqStack);

    cout << "Frequency stack (value then count, from top to bottom): ";
    ArrayStack<int> temp = resultStack.copy();
    while (!temp.isEmpty()) {
        int val, count;
        temp.pop(count);
        temp.pop(val);
        cout << "[" << val << ":" << count << "] ";
    }
    cout << endl;

    // Alternative frequency display
    cout << "\nExpected frequencies:\n";
    cout << "1 appears 1 time\n";
    cout << "2 appears 3 times\n";
    cout << "5 appears 3 times\n";
    cout << "8 appears 1 time\n";
    cout << "9 appears 1 time\n";

    // Test with empty stack
    cout << "\n--- Test 6: Empty Stack ---" << endl;
    ArrayStack<int> emptyStack;
    ArrayStack<int> emptyResult = frequency(emptyStack);
    cout << "Frequency of empty stack: " << (emptyResult.isEmpty() ? "Empty" : "Not empty") << endl;

    // Test with single element
    cout << "\n--- Test 7: Single Element Stack ---" << endl;
    ArrayStack<int> singleStack;
    singleStack.push(42);
    ArrayStack<int> singleResult = frequency(singleStack);
    cout << "Frequency of [42]: ";
    int v, c;
    singleResult.pop(c);
    singleResult.pop(v);
    cout << v << " appears " << c << " time(s)" << endl;

    cout << "\n========== ALL TESTS COMPLETED ==========" << endl;

    return 0;
}