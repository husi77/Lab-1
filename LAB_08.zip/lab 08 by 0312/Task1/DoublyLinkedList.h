#pragma once
class DoublyLinkedList {
public:
    virtual ~DoublyLinkedList() {}

    virtual bool isEmpty() = 0;
    virtual int getSize() = 0;
    virtual bool insertAtFirst(int val) = 0;
    virtual bool insertAtLast(int val) = 0;
    virtual bool removeFromFirst(int& val) = 0;
    virtual bool removeFromLast(int& val) = 0;
    virtual void displayForward() = 0;
    virtual void displayBackward() = 0;
};

