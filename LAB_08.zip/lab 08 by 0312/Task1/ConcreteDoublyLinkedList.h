#pragma once

#include "DoublyLinkedList.h"
#include "Node.h"

class ConcreteDoublyLinkedList : public DoublyLinkedList {
private:
    Node* head;
    Node* tail;
    int size;

public:
    ConcreteDoublyLinkedList();
    ~ConcreteDoublyLinkedList();

    bool isEmpty() ;
    int getSize() ;
    bool insertAtFirst(int val) ;
    bool insertAtLast(int val) ;
    bool removeFromFirst(int& val) ;
    bool removeFromLast(int& val) ;
    void displayForward() ;
    void displayBackward() ;
};

