﻿/**
 * Task 1: DoublyLinkedList Class Functions Implementation
 *
 * Step 1 - Understanding the Task:
 * I need to implement a DoublyLinkedList data structure where each node contains:
 * - data value (int)
 * - pointer to next node
 * - pointer to previous node
 *
 * The class should support operations like insert, remove, traverse forward/backward,
 * check if empty, get size, etc.
 *
 * Step 2 - Solution Approach:
 * - Create Node struct with data, next, prev pointers
 * - Implement ConcreteDoublyLinkedList class with head and tail pointers
 * - Functions needed: insertAtFirst, insertAtLast, removeFromFirst, removeFromLast,
 *   isEmpty, getSize, display
 * - Example: Empty list -> insertAtFirst(10) -> (10->)
 * - InsertAtFirst(5) -> (5->10->)
 * - removeFromFirst() -> returns 5, list becomes (10->)
 *
 * Step 3 - Functions Used and Why:
 * - Insert functions: add nodes at beginning or end (O(1))
 * - Remove functions: delete nodes from beginning or end (O(1))
 * - isEmpty: check if list has no nodes
 * - getSize: returns current size (O(1) with size variable)
 * - display: traverse and print all values
 *
 * Step 4 - Learning:
 * Understood how doubly linked lists work with prev pointers enabling
 * backward traversal and O(1) operations at both ends.
 *
 * Step 5 - Skills Developed:
 * Can implement any doubly linked list based data structures (Deque, LRU Cache, etc.)
 */

#include "ConcreteDoublyLinkedList.h"
#include <iostream>
using namespace std;

ConcreteDoublyLinkedList::ConcreteDoublyLinkedList()
    : head(nullptr), tail(nullptr), size(0) {}

ConcreteDoublyLinkedList::~ConcreteDoublyLinkedList() {
    while (!isEmpty()) {
        int temp;
        removeFromFirst(temp);
    }
}

bool ConcreteDoublyLinkedList::isEmpty() {
    return head == nullptr;
}

int ConcreteDoublyLinkedList::getSize() {
    return size;
}

bool ConcreteDoublyLinkedList::insertAtFirst(int val) {
    Node* newNode = new Node(val);

    if (isEmpty()) {
        head = tail = newNode;
    }
    else {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
    size++;
    return true;
}

bool ConcreteDoublyLinkedList::insertAtLast(int val) {
    Node* newNode = new Node(val);

    if (isEmpty()) {
        head = tail = newNode;
    }
    else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
    size++;
    return true;
}

bool ConcreteDoublyLinkedList::removeFromFirst(int& val) {
    if (isEmpty()) return false;

    val = head->data;
    Node* temp = head;

    if (head == tail) {
        head = tail = nullptr;
    }
    else {
        head = head->next;
        head->prev = nullptr;
    }

    delete temp;
    size--;
    return true;
}

bool ConcreteDoublyLinkedList::removeFromLast(int& val) {
    if (isEmpty()) return false;

    val = tail->data;
    Node* temp = tail;

    if (head == tail) {
        head = tail = nullptr;
    }
    else {
        tail = tail->prev;
        tail->next = nullptr;
    }

    delete temp;
    size--;
    return true;
}

void ConcreteDoublyLinkedList::displayForward() {
    Node* current = head;
    while (current != nullptr) {
        cout << current->data;
        if (current->next) cout << " -> ";
        current = current->next;
    }
    cout << endl;
}

void ConcreteDoublyLinkedList::displayBackward() {
    Node* current = tail;
    while (current != nullptr) {
        cout << current->data;
        if (current->prev) cout << " -> ";
        current = current->prev;
    }
    cout << endl;
}




//INT MAIN
#include "ConcreteDoublyLinkedList.h"
#include <iostream>
using namespace std;

int main() {
    cout << " TASK 1: DOUBLY LINKED LIST TEST \n\n";

    ConcreteDoublyLinkedList list;

    cout << "Initial list - Is empty? " << (list.isEmpty() ? "Yes" : "No") << endl;
    cout << "Size: " << list.getSize() << endl;

    cout << "\n--- Inserting elements ---" << endl;
    list.insertAtFirst(10);
    cout << "After insertAtFirst(10): ";
    list.displayForward();
    // Progression: () -> (10->)

    list.insertAtLast(20);
    cout << "After insertAtLast(20): ";
    list.displayForward();
    // Progression: (10->) -> (10->20->)

    list.insertAtFirst(5);
    cout << "After insertAtFirst(5): ";
    list.displayForward();
    // Progression: (10->20->) -> (5->10->20->)

    list.insertAtLast(30);
    cout << "After insertAtLast(30): ";
    list.displayForward();
    // Progression: (5->10->20->) -> (5->10->20->30->)

    list.insertAtLast(40);
    cout << "After insertAtLast(40): ";
    list.displayForward();
    // Progression: (5->10->20->30->) -> (5->10->20->30->40->)

    cout << "\nCurrent size: " << list.getSize() << endl;

    cout << "\nForward traversal: ";
    list.displayForward();

    cout << "Backward traversal: ";
    list.displayBackward();

    cout << "\n--- Removing elements ---" << endl;

    int removedVal;
    list.removeFromFirst(removedVal);
    cout << "Removed from first: " << removedVal << ", List: ";
    list.displayForward();
    // Progression: (5->10->20->30->40->) -> (10->20->30->40->)

    list.removeFromLast(removedVal);
    cout << "Removed from last: " << removedVal << ", List: ";
    list.displayForward();
    // Progression: (10->20->30->40->) -> (10->20->30->)

    list.removeFromFirst(removedVal);
    cout << "Removed from first: " << removedVal << ", List: ";
    list.displayForward();
    // Progression: (10->20->30->) -> (20->30->)

    list.removeFromLast(removedVal);
    cout << "Removed from last: " << removedVal << ", List: ";
    list.displayForward();
    // Progression: (20->30->) -> (20->)

    cout << "\nFinal size: " << list.getSize() << endl;
    cout << "Final list: ";
    list.displayForward();

    cout << "\n--- Removing remaining elements ---" << endl;
    list.removeFromFirst(removedVal);
cout << "Removed: " << removedVal << ", List empty? ";

if (list.isEmpty())
{
    cout << "Yes";
}
else
{
    cout << "No";
}

cout << endl;
    return 0;
}