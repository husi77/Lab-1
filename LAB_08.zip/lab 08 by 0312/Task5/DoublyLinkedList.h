﻿/**
* Task 5: Recursive Functions on DoublyLinkedList
*
* Step 1 - Understanding the Task:
* Convert iterative linked list functions to recursive versions:
* - copy: copy all elements to another list
* - display: print all elements
* - getSize: count number of elements
* - max: find maximum value
* - frequency: count frequency of each value
*
* Step 2 - Solution Approach:
* Base case: current node is NULL (end of list)
* Recursive case: process current node, then call on next node
*
* Example for copy:
*   List: 5 -> 2 -> 8
*   copy(5) -> copy(2) -> copy(8) -> copy(NULL)
*   Then insert 8, then 2, then 5 (order preserved)
*
* Step 3 - Functions Used:
* - Recursive calls with current->next
* - insertAtFirst/insertAtLast to build result
*
* Step 4 - Learning:
* Recursion on linked lists naturally follows the list structure
*
* Step 5 - Skills Developed:
* Can implement recursive algorithms on linked lists
*/
#pragma once
#include <iostream>
using namespace std;

class Node {
public:
	int data;
	Node* next;
	Node* prev;

	Node(int val) : data(val), next(nullptr), prev(nullptr) {}
};

class DoublyLinkedList {
private:
	Node* head;
	Node* tail;
	int size;

public:
	// Constructor & Destructor
	DoublyLinkedList() : head(nullptr), tail(nullptr), size(0) {}

	~DoublyLinkedList() {
		clear();
	}

	// Basic operations
	bool isEmpty() const {
		return head == nullptr;
	}

	int getSize() const {
		return size;
	}

	bool insertAtFirst(int val) {
		Node* newNode = new Node(val);

		if (isEmpty()) {
			head = tail = newNode;
		}
		else {
			newNode->next = head;
			head->prev = newNode;
			head = newNode;
		}
		size++;
		return true;
	}

	bool insertAtLast(int val) {
		Node* newNode = new Node(val);

		if (isEmpty()) {
			head = tail = newNode;
		}
		else {
			tail->next = newNode;
			newNode->prev = tail;
			tail = newNode;
		}
		size++;
		return true;
	}

	bool removeFromFirst(int& val) {
		if (isEmpty()) return false;

		val = head->data;
		Node* temp = head;

		if (head == tail) {
			head = tail = nullptr;
		}
		else {
			head = head->next;
			head->prev = nullptr;
		}

		delete temp;
		size--;
		return true;
	}

	bool removeFromLast(int& val) {
		if (isEmpty()) return false;

		val = tail->data;
		Node* temp = tail;

		if (head == tail) {
			head = tail = nullptr;
		}
		else {
			tail = tail->prev;
			tail->next = nullptr;
		}

		delete temp;
		size--;
		return true;
	}

	void displayForward() const {
		Node* current = head;
		while (current != nullptr) {
			cout << current->data;
			if (current->next) cout << " -> ";
			current = current->next;
		}
		cout << endl;
	}

	void displayBackward() const {
		Node* current = tail;
		while (current != nullptr) {
			cout << current->data;
			if (current->prev) cout << " -> ";
			current = current->prev;
		}
		cout << endl;
	}

	void clear() {
		while (!isEmpty()) {
			int temp;
			removeFromFirst(temp);
		}
	}

	DoublyLinkedList copy() const {
		DoublyLinkedList newList;
		Node* current = head;
		while (current != nullptr) {
			newList.insertAtLast(current->data);
			current = current->next;
		}
		return newList;
	}

	// ========== RECURSIVE FUNCTIONS ==========

	// 1. RECURSIVE COPY
	void copyRecursiveHelper(Node* current, DoublyLinkedList& dest) {
		if (current == nullptr) {
			return;
		}
		copyRecursiveHelper(current->next, dest);
		dest.insertAtFirst(current->data);
	}

	void copyRecursive(DoublyLinkedList& dest) {
		copyRecursiveHelper(head, dest);
	}

	// 2. RECURSIVE DISPLAY
	void displayRecursiveHelper(Node* current) {
		if (current == nullptr) {
			cout << endl;
			return;
		}
		cout << current->data;
		if (current->next) cout << " -> ";
		displayRecursiveHelper(current->next);
	}

	void displayRecursive() {
		displayRecursiveHelper(head);
	}

	// 3. RECURSIVE GET SIZE
	int getSizeRecursiveHelper(Node* current) {
		if (current == nullptr) {
			return 0;
		}
		return 1 + getSizeRecursiveHelper(current->next);
	}

	int getSizeRecursive() {
		return getSizeRecursiveHelper(head);
	}

	// 4. RECURSIVE MAX
	int maxRecursiveHelper(Node* current, int currentMax) {
		if (current == nullptr) {
			return currentMax;
		}
		if (current->data > currentMax) {
			currentMax = current->data;
		}
		return maxRecursiveHelper(current->next, currentMax);
	}

	int maxRecursive() {
		if (isEmpty()) {
			return -999;  // Return -999 for empty list
		}
		return maxRecursiveHelper(head->next, head->data);
	}

	// 5. RECURSIVE FREQUENCY

	// Helper: Find maximum value
	int findMaxValue(Node* current, int maxVal) {
		if (current == nullptr) {
			return maxVal;
		}
		if (current->data > maxVal) {
			maxVal = current->data;
		}
		return findMaxValue(current->next, maxVal);
	}

	// Helper: Find minimum value
	int findMinValue(Node* current, int minVal) {
		if (current == nullptr) {
			return minVal;
		}
		if (current->data < minVal) {
			minVal = current->data;
		}
		return findMinValue(current->next, minVal);
	}

	// Helper: Build frequency array recursively
	void frequencyRecursiveHelper(Node* current, int freq[], int minVal, int maxVal) {
		if (current == nullptr) {
			return;
		}
		int index = current->data - minVal;
		if (index >= 0 && index <= (maxVal - minVal)) {
			freq[index]++;
		}
		frequencyRecursiveHelper(current->next, freq, minVal, maxVal);
	}

	// Helper: Build result list recursively
	void buildResultListRecursive(int freq[], int val, int maxVal, DoublyLinkedList& result) {
		if (val > maxVal) {
			return;
		}
		buildResultListRecursive(freq, val + 1, maxVal, result);

		if (freq[val] > 0) {
			result.insertAtFirst(freq[val]);
			result.insertAtFirst(val);
		}
	}

	// Main frequency function
	DoublyLinkedList frequencyRecursive() {
		DoublyLinkedList result;

		if (isEmpty()) {
			return result;
		}

		int minVal = findMinValue(head->next, head->data);
		int maxVal = findMaxValue(head->next, head->data);

		int range = maxVal - minVal;
		int* freq = new int[range + 1]();

		frequencyRecursiveHelper(head, freq, minVal, maxVal);
		buildResultListRecursive(freq, 0, range, result);

		delete[] freq;
		return result;
	}
};

