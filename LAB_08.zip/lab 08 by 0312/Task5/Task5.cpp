﻿#include "DoublyLinkedList.h"
#include <iostream>
using namespace std;

int main() {
	cout << "========== TASK 5: RECURSIVE FUNCTIONS ON DOUBLYLINKEDLIST ==========\n\n";

	// Create and populate test list
	DoublyLinkedList list;

	cout << "Inserting elements: ";
	int testData[] = { 5, 2, 8, 2, 5, 2, 9, 5, 1 };
	for (int i = 0; i < 9; i++) {
		list.insertAtLast(testData[i]);
		cout << testData[i] << " ";
	}
	cout << endl;

	cout << "\nList forward: ";
	list.displayForward();

	cout << "List backward: ";
	list.displayBackward();

	//  TEST 1: RECURSIVE COPY 
	cout << "\n--- Test 1: copyRecursive ---" << endl;
	DoublyLinkedList copyList;
	list.copyRecursive(copyList);

	cout << "Original list: ";
	list.displayForward();
	cout << "Copied list:   ";
	copyList.displayForward();

	//  TEST 2: RECURSIVE DISPLAY 
	cout << "\n--- Test 2: displayRecursive ---" << endl;
	cout << "Display using recursion: ";
	list.displayRecursive();

	//  TEST 3: RECURSIVE GET SIZE 
	cout << "\n--- Test 3: getSizeRecursive ---" << endl;
	cout << "Size (recursive): " << list.getSizeRecursive() << endl;
	cout << "Size (actual):    " << list.getSize() << endl;

	//  TEST 4: RECURSIVE MAX 
	cout << "\n--- Test 4: maxRecursive ---" << endl;
	cout << "Maximum value (recursive): " << list.maxRecursive() << endl;

	//  TEST 5: RECURSIVE FREQUENCY 
	cout << "\n--- Test 5: frequencyRecursive ---" << endl;
	DoublyLinkedList freqList = list.frequencyRecursive();

	cout << "Frequency result (value:count): ";
	freqList.displayForward();

	cout << "\nExplanation: ";
	cout << "\n1 -> 1  means value 1 appears 1 time";
	cout << "\n2 -> 3  means value 2 appears 3 times";
	cout << "\n5 -> 3  means value 5 appears 3 times";
	cout << "\n8 -> 1  means value 8 appears 1 time";
	cout << "\n9 -> 1  means value 9 appears 1 time" << endl;

	//  TEST 6: EMPTY LIST 
	cout << "\n--- Test 6: Empty List ---" << endl;
	DoublyLinkedList emptyList;
	cout << "Empty list size (recursive): " << emptyList.getSizeRecursive() << endl;
	cout << "Empty list max (recursive): " << emptyList.maxRecursive() << endl;

	DoublyLinkedList emptyFreq = emptyList.frequencyRecursive();
	cout << "Empty list frequency: " << (emptyFreq.isEmpty() ? "Empty" : "Not empty") << endl;

	//  TEST 7: SINGLE ELEMENT LIST 
	cout << "\n--- Test 7: Single Element List ---" << endl;
	DoublyLinkedList singleList;
	singleList.insertAtLast(42);

	cout << "Single element list: ";
	singleList.displayForward();
	cout << "Size (recursive): " << singleList.getSizeRecursive() << endl;
	cout << "Max (recursive): " << singleList.maxRecursive() << endl;

	DoublyLinkedList singleFreq = singleList.frequencyRecursive();
	cout << "Frequency: ";
	singleFreq.displayForward();
	cout << "Meaning: 42 appears 1 time" << endl;

	//  TEST 8: LIST WITH NEGATIVE VALUES 
	cout << "\n--- Test 8: List with Negative Values ---" << endl;
	DoublyLinkedList negativeList;
	negativeList.insertAtLast(-5);
	negativeList.insertAtLast(3);
	negativeList.insertAtLast(-5);
	negativeList.insertAtLast(-2);
	negativeList.insertAtLast(3);
	negativeList.insertAtLast(-5);

	cout << "Negative list: ";
	negativeList.displayForward();

	DoublyLinkedList negFreq = negativeList.frequencyRecursive();
	cout << "Frequency: ";
	negFreq.displayForward();
	cout << "Meaning: -5 appears 3 times, -2 appears 1 time, 3 appears 2 times" << endl;

	//  TEST 9: ALL SAME VALUES 
	cout << "\n--- Test 9: All Same Values ---" << endl;
	DoublyLinkedList sameList;
	for (int i = 0; i < 5; i++) {
		sameList.insertAtLast(7);
	}

	cout << "All 7's list: ";
	sameList.displayForward();

	DoublyLinkedList sameFreq = sameList.frequencyRecursive();
	cout << "Frequency: ";
	sameFreq.displayForward();
	cout << "Meaning: 7 appears 5 times" << endl;

	cout << "\n========== ALL TESTS COMPLETED ==========\n";

	return 0;
}