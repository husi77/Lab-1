#pragma once

#include <iostream>
using namespace std;

class AbstractQueue
{
public:
    AbstractQueue() : count(0) {}
    AbstractQueue(const AbstractQueue& AQ);
    virtual void enqueue(int v) = 0;  // adds value at rear
    virtual bool dequeue(int& value) = 0;  // removes value from front
    bool isEmpty();

protected:
    int count;
};

AbstractQueue::AbstractQueue(const AbstractQueue& AQ) : count(AQ.count) {}

bool AbstractQueue::isEmpty()
{
    return (count == 0);
}