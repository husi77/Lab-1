﻿/**
 * Task 4: Recursive Functions on ArrayQueue (SIMPLIFIED)
 *
 * Step 1 - Understanding the Task:
 * Convert iterative queue functions to recursive versions:
 * - copyQueue: copy all elements from one queue to another
 * - display: print all elements
 * - getSize: count number of elements
 * - max: find maximum value
 * - frequency: count frequency of each value
 *
 * Step 2 - Solution Approach:
 * RECURSION PATTERN for Queue:
 *
 * Base Case: queue is empty -> stop/return 0/return
 * Recursive Case:
 *   1. Remove front element (dequeue)
 *   2. Do something with it
 *   3. Call function recursively on remaining queue
 *   4. Put element back (if needed to restore)
 *
 * Example for copyQueue:
 *   Queue: [1,2,3] (front to rear)
 *   Step: dequeue 1 -> recurse on [2,3]
 *   Step: dequeue 2 -> recurse on [3]
 *   Step: dequeue 3 -> recurse on empty
 *   Step: enqueue 3 -> enqueue 2 -> enqueue 1
 *   Result: [1,2,3] (order preserved!)
 *
 * Step 3 - Functions Used:
 * - dequeue() and enqueue() for queue operations
 * - Recursive calls with smaller queue each time
 *
 * Step 4 - Learning:
 * Queues preserve order when copying recursively (FIFO)
 * Unlike stacks which reverse order (LIFO)
 *
 * Step 5 - Skills Developed:
 * Can implement recursive functions on queues
 * Can convert iterative queue code to recursive
 */

#include "ArrayQueue.h"
#include <iostream>
using namespace std;

// ========== 1. RECURSIVE COPY QUEUE ==========
// Copies src queue to copy queue (preserves order)
void copyQueueRecursive(ArrayQueue& src, ArrayQueue& copy)
{
    // BASE CASE: src is empty -> nothing to copy
    if (src.isEmpty()) {
        return;
    }

    // RECURSIVE CASE: remove front, recurse, then add back
    int val;
    src.dequeue(val);

    copyQueueRecursive(src, copy);  // Recurse on remaining

    copy.enqueue(val);  // Add to copy (maintains order)
}

// ========== 2. RECURSIVE DISPLAY ==========
// Prints all elements (destructive - empties queue)
void displayRecursive(ArrayQueue& q)
{
    // BASE CASE: queue is empty
    if (q.isEmpty()) {
        cout << endl;
        return;
    }

    // RECURSIVE CASE: remove front, print it, recurse
    int val;
    q.dequeue(val);
    cout << val << " ";
    displayRecursive(q);
}

// Non-destructive version (works on a copy)
void display(ArrayQueue q)
{
    if (q.isEmpty()) {
        cout << endl;
        return;
    }

    int val;
    q.dequeue(val);
    cout << val << " ";
    display(q);
}

// ========== 3. RECURSIVE GET SIZE ==========
// Returns number of elements (destructive)
int getSizeRecursive(ArrayQueue& q)
{
    // BASE CASE: empty queue has size 0
    if (q.isEmpty()) {
        return 0;
    }

    // RECURSIVE CASE: remove one, count it + rest
    int val;
    q.dequeue(val);
    return 1 + getSizeRecursive(q);
}

// Non-destructive version
int getSize(ArrayQueue q)
{
    if (q.isEmpty()) {
        return 0;
    }

    int val;
    q.dequeue(val);
    return 1 + getSize(q);
}

// ========== 4. RECURSIVE MAX ==========
// Finds maximum value (destructive)
int maxRecursive(ArrayQueue& q)
{
    int val;
    q.dequeue(val);

    // BASE CASE: only one element left
    if (q.isEmpty()) {
        return val;
    }

    // RECURSIVE CASE: compare with max of rest
    int maxRest = maxRecursive(q);
    return (val > maxRest) ? val : maxRest;
}

// Non-destructive version
int max(ArrayQueue q)
{
    int val;
    q.dequeue(val);

    if (q.isEmpty()) {
        return val;
    }

    int maxRest = max(q);
    return (val > maxRest) ? val : maxRest;
}

// ========== 5. FREQUENCY FUNCTION (RECURSIVE) ==========

// Helper 1: Count how many times 'target' appears in queue
int countFrequency(ArrayQueue& q, int target)
{
    // BASE CASE
    if (q.isEmpty()) {
        return 0;
    }

    int val;
    q.dequeue(val);

    int count = (val == target) ? 1 : 0;
    count += countFrequency(q, target);

    return count;
}

// Helper 2: Get all unique values from queue (store in result queue)
void getUniqueValues(ArrayQueue& src, ArrayQueue& unique, ArrayQueue& seen)
{
    if (src.isEmpty()) {
        return;
    }

    int val;
    src.dequeue(val);

    // Check if already in seen queue
    ArrayQueue temp = seen.copy();
    bool found = false;
    while (!temp.isEmpty()) {
        int existing;
        temp.dequeue(existing);
        if (existing == val) {
            found = true;
            break;
        }
    }

    if (!found) {
        unique.enqueue(val);
        seen.enqueue(val);
    }

    getUniqueValues(src, unique, seen);
}

// Main frequency function
ArrayQueue frequency(ArrayQueue q)
{
    ArrayQueue result;

    if (q.isEmpty()) {
        return result;
    }

    // Step 1: Get all unique values
    ArrayQueue uniqueVals;
    ArrayQueue seen;
    ArrayQueue temp = q.copy();
    getUniqueValues(temp, uniqueVals, seen);

    // Step 2: For each unique value, count frequency
    ArrayQueue uniqueCopy = uniqueVals.copy();
    while (!uniqueCopy.isEmpty()) {
        int val;
        uniqueCopy.dequeue(val);

        // Count frequency of this value
        ArrayQueue countQueue = q.copy();
        int freq = countFrequency(countQueue, val);

        // Add to result (value then frequency)
        result.enqueue(val);
        result.enqueue(freq);
    }

    return result;
}

// ========== SIMPLER VERSION OF FREQUENCY ==========
// Using a fixed array for values 0-100 (simpler to understand)

ArrayQueue frequencySimple(ArrayQueue q)
{
    ArrayQueue result;

    if (q.isEmpty()) {
        return result;
    }

    // Frequency array for values 0-100
    int freq[101] = { 0 };

    // Count frequencies (destructive on copy)
    ArrayQueue temp = q.copy();
    while (!temp.isEmpty()) {
        int val;
        temp.dequeue(val);
        if (val >= 0 && val <= 100) {
            freq[val]++;
        }
    }

    // Build result queue
    for (int i = 0; i <= 100; i++) {
        if (freq[i] > 0) {
            result.enqueue(i);
            result.enqueue(freq[i]);
        }
    }

    return result;
}

// ========== MAIN FUNCTION ==========

int main()
{
    cout << "========== TASK 4: RECURSIVE FUNCTIONS ON QUEUE ==========\n\n";

    // Create test queue
    ArrayQueue q;
    int testData[] = { 5, 2, 8, 2, 5, 2, 9, 5, 1 };

    cout << "Enqueuing: ";
    for (int i = 0; i < 9; i++) {
        q.enqueue(testData[i]);
        cout << testData[i] << " ";
    }
    cout << endl;

    //  TEST 1: Recursive Display 
    cout << "\n--- 1. display (recursive) ---" << endl;
    cout << "Queue contents: ";
    display(q.copy());

    //  TEST 2: Recursive Get Size 
    cout << "\n--- 2. getSize (recursive) ---" << endl;
    cout << "Queue size: " << getSize(q.copy()) << endl;

    //  TEST 3: Recursive Max 
    cout << "\n--- 3. max (recursive) ---" << endl;
    cout << "Maximum value: " << max(q.copy()) << endl;

    //  TEST 4: Recursive Copy Queue 
    cout << "\n--- 4. copyQueueRecursive ---" << endl;
    ArrayQueue src = q.copy();
    ArrayQueue dest;
    copyQueueRecursive(src, dest);
    cout << "Original: ";
    display(q.copy());
    cout << "Copied:   ";
    display(dest);

    //  TEST 5: Frequency Function 
    cout << "\n--- 5. frequency (recursive) ---" << endl;
    ArrayQueue freqResult = frequency(q.copy());

    cout << "Frequency (value:count): ";
    ArrayQueue temp = freqResult.copy();
    cout << "[";
    bool first = true;
    while (!temp.isEmpty()) {
        int val, count;
        temp.dequeue(val);
        temp.dequeue(count);
        if (!first) cout << ", ";
        cout << val << ":" << count;
        first = false;
    }
    cout << "]" << endl;

    // Expected output
    cout << "\nExpected: [1:1, 2:3, 5:3, 8:1, 9:1]" << endl;

    //  TEST 6: Empty Queue 
    cout << "\n--- 6. Empty Queue Test ---" << endl;
    ArrayQueue empty;
    cout << "Empty queue size: " << getSize(empty) << endl;
    cout << "Empty queue frequency: ";
    ArrayQueue emptyFreq = frequency(empty);
    cout << (emptyFreq.isEmpty() ? "Empty" : "Not empty") << endl;

    //  TEST 7: Single Element 
    cout << "\n--- 7. Single Element Test ---" << endl;
    ArrayQueue single;
    single.enqueue(42);
    cout << "Queue: ";
    display(single.copy());
    cout << "Size: " << getSize(single.copy()) << endl;
    cout << "Max: " << max(single.copy()) << endl;

    ArrayQueue singleFreq = frequency(single.copy());
    cout << "Frequency: ";
    int v, c;
    singleFreq.dequeue(v);
    singleFreq.dequeue(c);
    cout << v << " appears " << c << " time(s)" << endl;

    cout << "\n ALL TESTS COMPLETED n";

    return 0;
}