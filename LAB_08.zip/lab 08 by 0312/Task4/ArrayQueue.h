#pragma once
#include<iostream>
using namespace std;

#include "AbstractQueue.h"

class ArrayQueue : public AbstractQueue
{
private:
    int* data;
    int front;
    int rear;
    int capacity;
    static const int DEFAULT_CAPACITY = 100;

    void resize();

public:
    ArrayQueue(int cap = DEFAULT_CAPACITY);
    ArrayQueue(const ArrayQueue& other);
    ~ArrayQueue();

    void enqueue(int v) override;
    bool dequeue(int& value) override;

    bool isFull() const;
    int getCapacity() const;
    void clear();

    // Assignment operator
    ArrayQueue& operator=(const ArrayQueue& other);

    // Helper function to create a copy
    ArrayQueue copy() const;

    // Helper to get front element without removing
    bool getFront(int& value) const;
};



ArrayQueue::ArrayQueue(int cap) : capacity(cap), front(0), rear(0)
{
    data = new int[capacity];
    count = 0;
}

ArrayQueue::ArrayQueue(const ArrayQueue& other) : AbstractQueue(other)
{
    capacity = other.capacity;
    front = other.front;
    rear = other.rear;
    data = new int[capacity];

    // Copy elements in order
    int index = front;
    for (int i = 0; i < count; i++) {
        data[index] = other.data[index];
        index = (index + 1) % capacity;
    }
}

ArrayQueue::~ArrayQueue()
{
    delete[] data;
}

void ArrayQueue::resize()
{
    int newCapacity = capacity * 2;
    int* newData = new int[newCapacity];

    // Copy elements in order
    int index = front;
    for (int i = 0; i < count; i++) {
        newData[i] = data[index];
        index = (index + 1) % capacity;
    }

    delete[] data;
    data = newData;
    front = 0;
    rear = count;
    capacity = newCapacity;
}

void ArrayQueue::enqueue(int v)
{
    if (count >= capacity) {
        resize();
    }
    data[rear] = v;
    rear = (rear + 1) % capacity;
    count++;
}

bool ArrayQueue::dequeue(int& value)
{
    if (isEmpty()) {
        return false;
    }
    value = data[front];
    front = (front + 1) % capacity;
    count--;
    return true;
}

bool ArrayQueue::isFull() const
{
    return count == capacity;
}

int ArrayQueue::getCapacity() const
{
    return capacity;
}

void ArrayQueue::clear()
{
    front = 0;
    rear = 0;
    count = 0;
}

ArrayQueue& ArrayQueue::operator=(const ArrayQueue& other)
{
    if (this != &other) {
        delete[] data;
        capacity = other.capacity;
        front = other.front;
        rear = other.rear;
        count = other.count;
        data = new int[capacity];

        int index = front;
        for (int i = 0; i < count; i++) {
            data[index] = other.data[index];
            index = (index + 1) % capacity;
        }
    }
    return *this;
}

ArrayQueue ArrayQueue::copy() const
{
    ArrayQueue newQueue(capacity);
    int index = front;
    for (int i = 0; i < count; i++) {
        newQueue.enqueue(data[index]);
        index = (index + 1) % capacity;
    }
    return newQueue;
}

bool ArrayQueue::getFront(int& value) const
{
    if (isEmpty()) {
        return false;
    }
    value = data[front];
    return true;
}